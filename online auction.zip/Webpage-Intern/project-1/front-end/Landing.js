import React from "react";
import { Link } from "react-router-dom";

const Landing = () => {
  return (
    <div>
      <h1>Welcome to the Online Auction Platform</h1>
      <p>Buy and sell items through live bidding!</p>
      <Link to="/dashboard"><button>View Auctions</button></Link>
      <Link to="/post-auction"><button>Post an Auction</button></Link>
    </div>
  );
};

export default Landing;
