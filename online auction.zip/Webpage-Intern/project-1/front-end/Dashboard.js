import React, { useEffect, useState } from "react";
import axios from "axios";
import AuctionItem from "../components/AuctionItem";

const Dashboard = () => {
  const [auctions, setAuctions] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/auctions")
      .then(response => setAuctions(response.data))
      .catch(error => console.error("Error fetching auctions:", error));
  }, []);

  return (
    <div>
      <h2>Live Auctions</h2>
      {auctions.map(auction => (
        <AuctionItem key={auction._id} auction={auction} />
      ))}
    </div>
  );
};

export default Dashboard;
