import React, { useState } from "react";
import axios from "axios";

const PostAuction = () => {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    startingPrice: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post("http://localhost:5000/api/auctions/create", formData)
      .then(response => {
        alert("Auction posted successfully!");
        setFormData({ title: "", description: "", startingPrice: "" });
      })
      .catch(error => console.error("Error posting auction:", error));
  };

  return (
    <div>
      <h2>Post a New Auction</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="title" value={formData.title} onChange={handleChange} placeholder="Auction Title" required />
        <textarea name="description" value={formData.description} onChange={handleChange} placeholder="Description" required></textarea>
        <input type="number" name="startingPrice" value={formData.startingPrice} onChange={handleChange} placeholder="Starting Price" required />
        <button type="submit">Create Auction</button>
      </form>
    </div>
  );
};

export default PostAuction;
