const express = require("express");
const Auction = require("../models/Auction");

const router = express.Router();

router.post("/create", async (req, res) => {
  const auction = new Auction(req.body);
  await auction.save();
  res.status(201).send(auction);
});

router.get("/", async (req, res) => {
  const auctions = await Auction.find();
  res.send(auctions);
});

module.exports = router;
