const mongoose = require("mongoose");

const AuctionSchema = new mongoose.Schema({
  title: String,
  description: String,
  startingPrice: Number,
  highestBid: { type: Number, default: 0 },
  highestBidder: { type: String, default: "" },
});

module.exports = mongoose.model("Auction", AuctionSchema);
