const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const http = require("http");
const socketIo = require("socket.io");
const auctionRoutes = require("./routes/auction");

const app = express();
const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: "http://localhost:3000" } });

app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/auction", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

app.use("/api/auctions", auctionRoutes);

io.on("connection", (socket) => {
  console.log("New client connected");

  socket.on("bid", async ({ auctionId, amount, bidder }) => {
    // Handle real-time bidding logic
    console.log(`New bid on auction ${auctionId}: ${amount} by ${bidder}`);
    io.emit("updateBid", { auctionId, amount, bidder });
  });

  socket.on("disconnect", () => console.log("Client disconnected"));
});

server.listen(5000, () => console.log("Server running on port 5000"));
